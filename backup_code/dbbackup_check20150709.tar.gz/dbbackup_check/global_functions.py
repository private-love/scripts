#!/bin/env python
#-*-coding:utf-8-*-

import MySQLdb
import string
import sys
import ConfigParser
import smtplib
import math
from email.mime.text import MIMEText
from email.message import Message
from email.header import Header

reload(sys)
sys.setdefaultencoding('utf8')


def get_config(group,config_name):
        config = ConfigParser.ConfigParser()
        config.readfp(open('./etc/config.ini','rw'))
        config_value=config.get(group,config_name).strip(' ').strip('\'').strip('\"')
        return config_value

mail_host = get_config('mail_server','mail_host')
mail_user = get_config('mail_server','mail_user')
mail_pass = get_config('mail_server','mail_pass')
mail_postfix = get_config('mail_server','mail_postfix')
mailto_list_str = get_config('mail_server','mailto_list')
mailto_list = mailto_list_str.split(",")

host = get_config('backup_db_server','host')
port = get_config('backup_db_server','port')
user = get_config('backup_db_server','user')
passwd = get_config('backup_db_server','passwd')
dbname = get_config('backup_db_server','dbname')

idc_type = get_config('idc','idc_type')
key_path = get_config('key_info','key_path_file')
key_user = get_config('key_info','key_user')

def connect_db():
	conn=MySQLdb.connect(host=host,user=user,passwd=passwd,port=int(port),connect_timeout=10,charset='utf8')
    	conn.select_db(dbname)
    	cursor = conn.cursor()
	return cursor

def mysql_exec(sql,param):
    	conn=MySQLdb.connect(host=host,user=user,passwd=passwd,port=int(port),connect_timeout=10,charset='utf8')
    	conn.select_db(dbname)
    	cursor = conn.cursor()
    	if param <> '':
        	cursor.execute(sql,param)
    	else:
        	cursor.execute(sql)
    	conn.commit()
    	cursor.close()
    	conn.close()

def mysql_query(sql):
    	conn=MySQLdb.connect(host=host,user=user,passwd=passwd,port=int(port),connect_timeout=10,charset='utf8')
    	conn.select_db(dbname)
    	cursor = conn.cursor()
    	count=cursor.execute(sql)
    	if count == 0 :
        	result=0
    	else:
        	result=cursor.fetchall()
    	cursor.close()
    	conn.close()
    	return result

def send_mail(to_list,sub,content):
	'''
	to_list:发给谁
	sub:主题
    	content:内容
    	send_mail("xxxx@126.com","sub","content")
    	'''
    	me = mail_user
    	#me=mail_user+"<</span>"+mail_user+"@"+mail_postfix+">"
    	msg = MIMEText(content, 'html', 'utf-8')
    	msg['Subject'] = Header(sub,'utf-8')
    	#msg['From'] = Header(me,'utf-8')
    	msg['From'] = me
    	msg['To'] = ";".join(to_list)
    	try:
       		s = smtplib.SMTP()
        	s.connect(mail_host)
        	s.login(mail_user,mail_pass)
        	s.sendmail(me,to_list, msg.as_string())
        	s.close()
        	return True
    	except Exception, e:
        	print str(e)
        	return False

def toErrHtml(dict):
        html = ""
        html += "<table width=\"600\" border=\"1\" cellspacing=\"0\" cellpadding=\"2\">"
        html += "<tr style=\"text-align:center;\"><td>服务器</td><td>原因</td></tr>"
        for key,value in dict.items():
                list = value.split('###')
                id = list[0]
                reason = list[1]
                html += "<tr align=\"justify\" >"
                html += "<td nowrap=\"nowrap\" style=\"padding:0px 10px;\">"
                html += "<a href=\"http://racktables.ci123.com/backup/backup_host_add.php?id="+id+"\" target=\"_blank\">"+str(key)+"</a>"
                html += "</td>"

                html += "<td nowrap=\"nowrap\" style=\"padding:0px 10px;\">"
                html += str(reason)
                html += "</td>"
                html += "</tr>"
        html += "</table>"
        return html

def toHtml(list,total_size_str):
	#把list转换为dict
	dict = {}
    	key_list = []
    	for line in list:
        	line = line[0]
        	line = line.split(',')
        	key = line[0]
        	value = line[1:]
        	if key not in dict:
            		key_list.append(key)
            		dict[key] = []
            		dict[key].append(value)
        	else:
            		dict[key].append(value)


    	#写成html表格
    	html = ""
    	html += "<table width=\"600\" border=\"1\" cellspacing=\"0\" cellpadding=\"2\">"
    	html += "<tr style=\"text-align:center;\"><td>IP</td><td>备份</td><td>备份日期</td><td style=\"text-align:center;\">大小</td><td>文件</td><td>文件夹路径</td></tr>"
    	count = True
	total_row = 0
	total_db = 0
    	for key in key_list:
        	data = dict[key]
        	n = len(data)
		total_row += 1
        	for d in data:
            		html += "<tr align=\"justify\" >"

            		if(count):
                		html += "<td nowrap=\"nowrap\" rowspan="+ str(n) +" style=\"padding:0px 10px;\">"
                		html += str(key)
                		html += "</td>"
                		count = False

            		iserror = not d[-2].strip(" ")
			total_db += 1
            		for i in d:
				
                		if (not i.strip(' ')):
                    			html += "<td nowrap=\"nowrap\" bgcolor=\"red\" style=\"padding:0px 10px;\">"
                    			html += str('backup error')
                		else:
                    			if iserror:
                        			html += "<td nowrap=\"nowrap\" bgcolor=\"red\" style=\"padding:0px 10px;\">"
                        			html += str(i)
                    			else:
                        			html += "<td nowrap=\"nowrap\" style=\"padding:0px 10px;\">"
                        			html += str(i)
                		html += "</td>"

            		html += "</tr>"
        	count = True
	if total_size_str :
		html += "<tr style=\"padding:0px 10px;height:30px;\"><td>备份概述：</td><td colspan=\"5\">"+str(total_row)+"台服务器，"+str(total_db)+"个数据库实例，备份总量："+str(total_size_str)+"</td></tr>"

    	html += "</table>"
    	return html

def convertBytes(bytes,lst=['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB']):
        i = int(math.floor(math.log(bytes, 1024)))
        if i >= len(lst):
        	i = len(lst) - 1
        return ('%.2f' + " " + lst[i]) % (bytes/math.pow(1024, i))
